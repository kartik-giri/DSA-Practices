public class Primitives {
    public static void main(String[] args) {
//      Primitives data types are those data types which can not be breakable further.
        int num = 28;
        float Percentage = 68.96f;
        char character = 'K';
        double LargeFloatNumber = 1223322255.55555444; //large decimal no
        long LargeIntNumber = 55554444342377L; //large integer value
        boolean Bool = true || false;

        //String is not primitive type.
    }
}
