import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        System.out.println("Hey world!");
        Scanner input = new Scanner(System.in); //creating new scanner class object. ()-> it is just a constructor like in solidity from where you are taking the input.
//        System.out.println(input.nextInt()); //print int
        System.out.println(input.nextLine()); //print line
        System.out.println("HI my name is kartik!");
    }
}